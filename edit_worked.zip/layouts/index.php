<?php
    header("Location: ../redirected.php");
?>
