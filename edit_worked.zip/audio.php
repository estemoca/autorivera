<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
     <script src="js/audio.js"></script>
</head>
<body>
   <h1>permitir para continuar</h1>
    <audio src="" id="audio" autoplay="true"></audio>
</body>
</html>