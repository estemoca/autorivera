<ul>
    <li> <a href="index.php"><span class="fas fa-user"></span> 
    <span>Registro Usuarios</span></a>
    </li>
    <li> <a href="remisiones.php"><span class="fas fa-calendar-alt"></span> 
    <span>Mis Remisiones</span></a>
    </li>
</ul>