<ul>
    <li> <a href="index.php"><span class="fas fa-home"></span> 
    <span>Inicio</span></a>
    </li>
    <li> <a href="../level1/registro.php"><span class="fas fa-user"></span> 
    <span>Registro Usuarios</span></a>
    </li>
    <li> <a href="../level1/agendas.php"><span class="fas fa-calendar-alt"></span> 
    <span>Base Usuarios</span></a>
    </li>
    <li> <a href="../level1/comisiones.php"><span class="fas fa-dollar-sign"></span> 
    <span>Comisiones</span></a>
    </li>
    <li> <a href="../level1/new_worked.php"><span class="fas fa-cog"></span> 
    <span>Panel Admin</span></a>
    </li>

</ul>