<ul>
    <li> <a href="index.php"><span class="fas fa-home"></span> 
    <span>Inicio</span></a>
    </li>
    <li> <a href="../level3/registro.php"><span class="fas fa-user"></span> 
    <span>Registro Usuarios</span></a>
    </li>
    <li> <a href="../level3/agendas.php"><span class="fas fa-calendar-alt"></span> 
    <span>Base Usuarios</span></a>
    </li>
    <li> <a href="../level3/comisiones.php"><span class="fas fa-dollar-sign"></span> 
    <span>Comisiones</span></a>
    </li>
</ul>